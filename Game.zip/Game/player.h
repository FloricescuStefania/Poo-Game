﻿#pragma once

#include <string>
using namespace std;

class Player
{
private:
	string name;
	int age;

public:
	Player();
};