#pragma once

class Round1 {

private:
	int score;
	string suspectName;

public:
	void begin();
	void interrogate();
	void riskyChoice();
 };